 <!-- subscribe start -->
 {{-- <div class="subscribe-area">
    <div class="container">
        <div class="subscribe-box">
            <div class="row">
                <div class="col-xl-10 offset-xl-1 col-lg-10 offset-lg-1 col-md-12">
                    <div class="row justify-content-between">
                        <div class="col-xl-6 col-lg-7 col-md-8">
                            <div class="subscribe-text">
                                <h1>Subscribe</h1>
                                <span>Enter your email and get latest updates and offers subscribe us</span>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-4 justify-content-end">
                            <div class="email-submit-form">
                                <div class="subscribe-form">
                                    <form action="#">
                                        <input placeholder="Enter your email" type="email">
                                        <i class="fas fa-long-arrow-alt-right"></i>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> --}}
<!-- subscribe end -->
<!-- footer start -->
<footer id="Contact">
    <div class="footer-area primary-bg pt-150">
        <div class="container">
            <div class="footer-top pb-35">
                <div class="row">
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="footer-widget mb-30">
                            <div class="footer-logo">
                                <img src="/assets/frontend/sikka/img/logo/logo_2.png" alt="">
                            </div>
                            <div class="footer-para">
                                <p> Web ini sebagai media catatan pengetahuan yang sekiranya bermanfaat </p>
                            </div>
                            <div class="footer-socila-icon">
                                <span>Follow Us</span>
                                <div class="footer-social-icon-list">
                                    <ul>
                                        <li><a href="#"><span class="ti-facebook"></span></a></li>
                                        <li><a href="#"><span class="ti-google"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="footer-widget mb-30">
                            <div class="footer-heading">
                                <h1>Quick Links</h1>
                            </div>
                            <div class="footer-menu clearfix">
                                <ul>
                                    <li><a href="{{ route('all') }}">Artikel</a></li>
                                    <li><a href="#">Tentang</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 d-lg-none d-xl-block col-md-6">
                        <div class="footer-widget mb-30">
                            <div class="footer-heading">
                                <h1>Recent Post</h1>
                            </div>
                            <div class="recent-post d-flex mb-25">
                                <div class="recent-post-thumb">
                                    <img src="/assets/frontend/sikka/img/post/recent_post1.jpg" alt="">
                                </div>
                                <div class="recent-post-text">
                                    <p>Neque porro quisquam est qui dolorem ipsum</p>
                                    <div class="footer-time">
                                        <span class="ti-time"></span>
                                        <span class="footer-published-time">05 May 2018</span>
                                    </div>
                                </div>
                            </div>
                            <div class="recent-post d-flex">
                                <div class="recent-post-thumb">
                                    <img src="/assets/frontend/sikka/img/post/recent_post1.jpg" alt="">
                                </div>
                                <div class="recent-post-text">
                                    <p>Neque porro quisquam est qui dolorem ipsum</p>
                                    <div class="footer-time">
                                        <span class="ti-time"></span>
                                        <span class="footer-published-time">05 May 2018</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4  col-md-6">
                        <div class="footer-widget mb-30">
                            <div class="footer-heading">
                                <h1>Contact Us</h1>
                            </div>
                            <div class="footer-contact-list">
                                <div class="single-footer-contact-info">
                                    <span class="ti-email "></span>
                                    <span class="footer-contact-list-text">kodir.petani@gmail.com</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom pt-25 pb-25">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="footer-copyright text-left">
                                <span><a target="_blank" href="https://www.templateshub.net/template/Sikkha-Education-Free-Website-Template">Template Sikka by Templates Hub</a></span>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="footer-copyright text-right">
                                <span><a href="https://www.zaelani.id">www.zaelani.id</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer end -->


<!-- JS here -->
<script src="/assets/frontend/sikka/js/vendor/modernizr-3.5.0.min.js"></script>
<script src="/assets/frontend/sikka/js/vendor/jquery-1.12.4.min.js"></script>
<script src="/assets/frontend/sikka/js/popper.min.js"></script>
<script src="/assets/frontend/sikka/js/bootstrap.min.js"></script>

{{-- <script src="/assets/frontend/sikka/js/owl.carousel.min.js"></script> --}}
<script src="/assets/frontend/sikka/js/isotope.pkgd.min.js"></script>
<script src="/assets/frontend/sikka/js/one-page-nav-min.js"></script>
<script src="/assets/frontend/sikka/js/slick.min.js"></script>
<script src="/assets/frontend/sikka/js/ajax-form.js"></script>
<script src="/assets/frontend/sikka/js/wow.min.js"></script>
<script src="/assets/frontend/sikka/js/jquery.meanmenu.min.js"></script>
<script src="/assets/frontend/sikka/js/jquery.scrollUp.min.js"></script>
<script src="/assets/frontend/sikka/js/jquery.barfiller.js"></script>
<script src="/assets/frontend/sikka/js/imagesloaded.pkgd.min.js"></script>
<script src="/assets/frontend/sikka/js/jquery.counterup.min.js"></script>
<script src="/assets/frontend/sikka/js/waypoints.min.js"></script>
<script src="/assets/frontend/sikka/js/jquery.magnific-popup.min.js"></script>
<script src="/assets/frontend/sikka/js/plugins.js"></script>
<script src="/assets/frontend/sikka/js/main.js"></script>
</body>
</html>